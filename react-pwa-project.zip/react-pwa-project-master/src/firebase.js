import firebase from 'firebase'
var firebaseConfig = {
    apiKey: "AIzaSyAD2mE_w_CDDEIinVpplP4iK9ncllAgiW8",
    authDomain: "pwa-app-ccb69.firebaseapp.com",
    databaseURL: "https://pwa-app-ccb69.firebaseio.com",
    projectId: "pwa-app-ccb69",
    storageBucket: "pwa-app-ccb69.appspot.com",
    messagingSenderId: "87598063745",
    appId: "1:875918063745:web:366bb079c60e9d08cdb580"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
export default firebase